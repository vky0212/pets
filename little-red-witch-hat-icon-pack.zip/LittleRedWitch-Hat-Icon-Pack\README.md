# 小紅巫帽子 Icon Pack

以小紅巫的紅色軟帽為主題，針對 Windows 桌面程式與捷徑辨識度設計。所有 PNG 都是 RGBA 透明背景。

## 內容

- `LittleRedWitch-Hat.ico`：包含 16、20、24、32、40、48、64、96、128、256 px。
- `witch-hat-icon-master-1024.png`：1024 px 透明母版。
- `png/`：16、20、24、32、40、48、64、96、128、256、512、1024 px 個別 PNG。
- `icon-size-preview.png`：各種尺寸的視覺預覽。

## 建議用途

- Windows EXE：使用 `LittleRedWitch-Hat.ico`。
- 網站 favicon：16、32、48 px PNG，或直接使用 ICO。
- 應用程式介面：24、32、40、48、64 px PNG。
- 商店頁面或高 DPI 顯示：256、512、1024 px PNG。
