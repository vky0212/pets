Q版紅帽巫婆娃娃 — Codex v2 寵物

安裝方式（Windows）：
1. 將整個 redhood-witch-doll-chibi 資料夾解壓縮到：
   C:\Users\你的帳號\.codex\pets\
2. 完整路徑應為：
   C:\Users\你的帳號\.codex\pets\redhood-witch-doll-chibi\pet.json
3. 重新啟動 Codex，然後選擇「Q版紅帽巫婆娃娃」。

必要檔案：
- pet.json
- spritesheet.webp

規格：spriteVersionNumber 2、8×11、1536×2288。
